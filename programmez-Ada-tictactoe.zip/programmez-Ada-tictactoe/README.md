Différentes étapes de l'exemple utilisé dans l'article:

  Ada, le langage qui structure votre code et vos idées

  https://www.programmez.com/

Chaque exemple montre la progression en suivant l'article.
Installez Alire comme indiqué sur: https://ada-lang.io/

Les exemples sont compilés avec la commande:

    cd step-<I>/tictactoe
    alr build

Les différents exemples ont pour but de montrer la progression
et permettent de voir facilement les différences entre eux
(ex: `diff step-3 step-4`).

* step-1 (Démarrons avec Alire)
  Premier programme équivalent au Hello World!

* step-2 (Démarrons avec Alire)
  Exécution avec AnsiAda

* step-3 (Un peu de code)
  Exemple Tic-Tac-Toe complet et fonctionnel

* step-4 (Des préconditions pour vérifier)
  Ajout de pre et post conditions

* step-5 (Un peu de SPARK)
  Ajout du mode SPARK et des invariants de boucle pour prouver le programme.
