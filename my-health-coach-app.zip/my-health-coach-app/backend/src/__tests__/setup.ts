// Configuration Jest pour les tests
import dotenv from 'dotenv';

// Charger les variables d'environnement de test
dotenv.config({ path: '.env.test' });

// Configuration globale pour les tests
global.console = {
  ...console,
  // Supprimer les logs pendant les tests sauf erreurs
  log: jest.fn(),
  debug: jest.fn(),
  info: jest.fn(),
  warn: jest.fn(),
  error: console.error,
};

// Timeout par défaut pour les tests
jest.setTimeout(10000);
