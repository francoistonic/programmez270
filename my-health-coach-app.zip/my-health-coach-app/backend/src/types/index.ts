// Types TypeScript pour My Health Coach Backend

export interface PatientContext {
  age?: number;
  gender?: string;
  medicalHistory?: string;
  consultationReason?: string;
}

export interface AnalyzeDocumentRequest {
  medicalData: string;
  patientContext?: PatientContext;
}

export interface AnalyzeDocumentResponse {
  success: boolean;
  analysis: string;
  timestamp: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ChatRequest {
  conversation: ChatMessage[];
}

export interface ChatResponse {
  success: boolean;
  response: string;
  timestamp: string;
}

export interface ApiError {
  error: string;
  message?: string;
  path?: string;
}

export interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy';
  timestamp: string;
  version: string;
}

export interface ReadinessCheckResponse {
  status: 'ready' | 'not-ready';
  services: {
    llmaas: 'connected' | 'disconnected';
    database?: 'connected' | 'disconnected';
  };
}

export interface LLMaaSUsage {
  model: string;
  prompt_tokens: number;
  completion_tokens: number;
  total_tokens: number;
  timestamp: string;
}
