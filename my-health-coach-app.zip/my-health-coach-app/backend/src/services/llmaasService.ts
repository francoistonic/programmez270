import fetch from 'node-fetch';
import { logger } from '../utils/logger';
import type { PatientContext } from '../types';

interface LLMaaSRequest {
  model: string;
  messages: Array<{
    role: 'system' | 'user' | 'assistant';
    content: string;
  }>;
  temperature?: number;
  max_tokens?: number;
}

interface LLMaaSResponse {
  choices: Array<{
    message: {
      content: string;
      role: string;
    };
  }>;
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

/**
 * Service d'intégration avec Cloud Temple LLMaaS
 * Permet l'accès aux 36 modèles d'IA générative hébergés en France
 * Conforme aux exigences SecNumCloud et HDS
 */
export class LLMaaSService {
  private apiUrl: string;
  private apiKey: string;
  private defaultModel: string;

  constructor() {
    this.apiUrl = process.env.LLMAAS_API_URL || 'https://llmaas.cloud-temple.com/v1';
    this.apiKey = process.env.LLMAAS_API_KEY || '';
    this.defaultModel = process.env.LLMAAS_MODEL || 'qwen3-30b';

    if (!this.apiKey) {
      throw new Error('LLMAAS_API_KEY environment variable is required');
    }
  }

  /**
   * Analyse un document médical et génère des questions pertinentes
   * Utilise Qwen3 30B optimisé pour le français médical
   */
  async analyzeDocument(medicalData: string, patientContext: PatientContext): Promise<string> {
    const prompt = this.buildMedicalPrompt(medicalData, patientContext);
    
    try {
      const response = await this.callLLMaaS({
        model: this.defaultModel,
        messages: [
          {
            role: 'system',
            content: 'Vous êtes un assistant médical IA spécialisé dans l\'analyse de documents médicaux français. Votre rôle est d\'aider les patients à préparer leurs rendez-vous médicaux en générant des questions pertinentes basées sur leurs dossiers médicaux. Respectez les contraintes déontologiques françaises et la confidentialité médicale.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: 0.3,
        max_tokens: 1000
      });

      return response.choices[0]?.message?.content || 'Désolé, je n\'ai pas pu analyser ce document.';
    } catch (error) {
      logger.error('Erreur lors de l\'analyse du document médical:', error);
      return this.fallbackResponse();
    }
  }

  /**
   * Génère une réponse conversationnelle
   */
  async generateResponse(conversation: Array<{role: 'user' | 'assistant', content: string}>): Promise<string> {
    try {
      const response = await this.callLLMaaS({
        model: this.defaultModel,
        messages: [
          {
            role: 'system',
            content: 'Vous êtes My Health Coach, un assistant médical IA bienveillant qui aide les patients à mieux comprendre leur santé. Répondez en français, de manière claire et rassurante, sans donner de conseils médicaux directs.'
          },
          ...conversation.map(msg => ({
            role: msg.role as 'user' | 'assistant',
            content: msg.content
          }))
        ],
        temperature: 0.4,
        max_tokens: 800
      });

      return response.choices[0]?.message?.content || 'Je ne peux pas répondre à cette question pour le moment.';
    } catch (error) {
      logger.error('Erreur lors de la génération de réponse:', error);
      return 'Désolé, je rencontre des difficultés techniques. Veuillez réessayer plus tard.';
    }
  }

  /**
   * Construit un prompt médical contextualisé
   */
  private buildMedicalPrompt(medicalData: string, patientContext: PatientContext): string {
    return `
Analysez les données médicales suivantes et générez 5-7 questions pertinentes que le patient pourrait poser à son médecin lors de son prochain rendez-vous.

Contexte du patient:
- Âge: ${patientContext.age || 'Non spécifié'}
- Sexe: ${patientContext.gender || 'Non spécifié'}
- Antécédents: ${patientContext.medicalHistory || 'Aucun antécédent connu'}
- Motif de consultation: ${patientContext.consultationReason || 'Consultation de routine'}

Données médicales à analyser:
${medicalData}

Instructions:
1. Générez des questions spécifiques et pertinentes basées sur les données
2. Utilisez un langage accessible au patient
3. Priorisez les éléments qui nécessitent une clarification médicale
4. Incluez des questions sur les traitements si applicable
5. Respectez la confidentialité médicale
6. Répondez uniquement en français

Format de réponse:
- Question 1: [question]
- Question 2: [question]
- etc.
`;
  }

  /**
   * Appel à l'API LLMaaS Cloud Temple
   * API REST standardisée compatible OpenAI
   * Authentification Bearer Token sécurisée
   */
  private async callLLMaaS(request: LLMaaSRequest): Promise<LLMaaSResponse> {
    const response = await fetch(`${this.apiUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        'User-Agent': 'MyHealthCoach/1.0',
        'X-Request-ID': this.generateRequestId()
      },
      body: JSON.stringify(request)
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`LLMaaS API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json() as LLMaaSResponse;
    
    // Log usage pour monitoring et conformité
    logger.info('LLMaaS usage', {
      model: request.model,
      prompt_tokens: data.usage?.prompt_tokens,
      completion_tokens: data.usage?.completion_tokens,
      total_tokens: data.usage?.total_tokens,
      timestamp: new Date().toISOString()
    });

    return data;
  }

  /**
   * Génère un ID unique pour traçabilité des requêtes
   */
  private generateRequestId(): string {
    return `mhc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Réponse de fallback en cas d'erreur
   */
  private fallbackResponse(): string {
    return `Je ne peux pas analyser ce document pour le moment. Voici quelques questions générales que vous pourriez poser à votre médecin :

- Docteur, pouvez-vous m'expliquer mes derniers résultats d'analyses ?
- Y a-t-il des points particuliers à surveiller dans mon état de santé ?
- Mon traitement actuel est-il toujours adapté ?
- Quand devrais-je programmer mon prochain rendez-vous ?
- Y a-t-il des examens complémentaires à prévoir ?`;
  }
}

export const llmaasService = new LLMaaSService();
