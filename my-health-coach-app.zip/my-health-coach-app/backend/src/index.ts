import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { logger, logRequest } from './utils/logger';
import { llmaasService } from './services/llmaasService';
import type { 
  AnalyzeDocumentRequest, 
  AnalyzeDocumentResponse, 
  ChatRequest, 
  ChatResponse,
  HealthCheckResponse,
  ReadinessCheckResponse,
  ApiError 
} from './types';

// Charger les variables d'environnement
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares de sécurité
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
}));

app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://localhost:3000',
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Middleware de logging
app.use(logRequest);

// Routes de santé
app.get('/health', (req: express.Request, res: express.Response<HealthCheckResponse>) => {
  res.status(200).json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

app.get('/ready', (req: express.Request, res: express.Response<ReadinessCheckResponse>) => {
  res.status(200).json({
    status: 'ready',
    services: {
      llmaas: 'connected'
    }
  });
});

// Routes API
app.post('/api/v1/analyze-document', async (
  req: express.Request<{}, AnalyzeDocumentResponse | ApiError, AnalyzeDocumentRequest>, 
  res: express.Response<AnalyzeDocumentResponse | ApiError>
) => {
  try {
    const { medicalData, patientContext } = req.body;

    if (!medicalData || typeof medicalData !== 'string') {
      return res.status(400).json({
        error: 'Medical data is required and must be a string'
      });
    }

    const analysis = await llmaasService.analyzeDocument(medicalData, patientContext || {});

    res.json({
      success: true,
      analysis,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error analyzing document:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Unable to analyze document'
    });
  }
});

app.post('/api/v1/chat', async (
  req: express.Request<{}, ChatResponse | ApiError, ChatRequest>, 
  res: express.Response<ChatResponse | ApiError>
) => {
  try {
    const { conversation } = req.body;

    if (!conversation || !Array.isArray(conversation)) {
      return res.status(400).json({
        error: 'Conversation history is required and must be an array'
      });
    }

    // Validation des messages
    for (const message of conversation) {
      if (!message.role || !message.content || 
          !['user', 'assistant'].includes(message.role)) {
        return res.status(400).json({
          error: 'Invalid conversation format'
        });
      }
    }

    const response = await llmaasService.generateResponse(conversation);

    res.json({
      success: true,
      response,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    logger.error('Error generating chat response:', error);
    res.status(500).json({
      error: 'Internal server error',
      message: 'Unable to generate response'
    });
  }
});

// Gestion des erreurs 404
app.use('*', (req: express.Request, res: express.Response<ApiError>) => {
  res.status(404).json({
    error: 'Route not found',
    path: req.originalUrl
  });
});

// Gestion globale des erreurs
app.use((error: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
  logger.error('Unhandled error:', error);
  res.status(500).json({
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
  });
});

// Démarrage du serveur
app.listen(PORT, () => {
  logger.info(`My Health Coach API started on port ${PORT}`);
  logger.info(`Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`LLMaaS Model: ${process.env.LLMAAS_MODEL || 'qwen3-30b'}`);
});

// Gestion gracieuse de l'arrêt
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully');
  process.exit(0);
});

export default app;
