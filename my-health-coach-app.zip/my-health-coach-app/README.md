# My Health Coach - Application IA de Santé

## Description

My Health Coach est une application d'assistance médicale intelligente qui aide les patients à préparer leurs rendez-vous médicaux. L'application analyse les dossiers médicaux grâce à l'IA et génère automatiquement des questions pertinentes à poser lors des consultations.

## Architecture

- **Frontend** : React 18 + TypeScript + Material-UI
- **Backend** : Node.js + Express + TypeScript + Prisma
- **Base de données** : PostgreSQL 15
- **IA** : Intégration Cloud Temple LLMaaS (Mistral Large)
- **Infrastructure** : Docker + Kubernetes (OpenShift)

## Fonctionnalités

- Upload sécurisé de documents médicaux
- Analyse IA des dossiers médicaux
- Génération de questions personnalisées
- Interface conversationnelle
- Historique des consultations
- Conformité RGPD et HDS

## Déploiement sur Cloud Temple

### Prérequis

- Compte Cloud Temple avec accès PaaS OpenShift
- Clé API LLMaaS Cloud Temple
- Base de données PostgreSQL

### Variables d'environnement

```bash
# Application
NODE_ENV=production
PORT=3000
API_VERSION=v1

# Base de données
DATABASE_URL=postgresql://user:pass@postgres:5432/healthcoach
DATABASE_SSL=true

# Cloud Temple LLMaaS
LLMAAS_API_URL=https://llmaas.cloud-temple.com/v1
LLMAAS_API_KEY=ct_xxx
LLMAAS_MODEL=mistral-large

# Sécurité
JWT_SECRET=your-jwt-secret
ENCRYPTION_KEY=your-encryption-key
CORS_ORIGIN=https://myapp.cloud-temple.com
```

### Installation

1. **Cloner le repository**
```bash
git clone <repository-url>
cd my-health-coach-app
```

2. **Installer les dépendances**
```bash
# Backend
cd backend
npm install

# Frontend
cd ../frontend
npm install
```

3. **Configuration de la base de données**
```bash
cd backend
npx prisma migrate deploy
npx prisma generate
```

4. **Déploiement sur OpenShift**
```bash
# Appliquer les manifestes Kubernetes
kubectl apply -f k8s/
```

## Développement local

### Backend
```bash
cd backend
npm run dev
```

### Frontend
```bash
cd frontend
npm run dev
```

## Sécurité

- Chiffrement TLS 1.3 end-to-end
- Données sensibles chiffrées AES-256
- Authentification JWT + OAuth2
- RBAC Kubernetes
- Audit trail complet
- Conformité RGPD/HDS

## Support

Pour toute question technique, contactez l'équipe de développement ou consultez la documentation Cloud Temple.

## Licence

Propriétaire - Tous droits réservés
